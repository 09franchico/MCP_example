import style from './NavBarra.module.css'
import Container from './Container'
import { Link } from 'react-router-dom'
import logo from '../../img/costs_logo.png'

function NavBarra(){
    return(
        <nav className={style.nav_barra}>
            <Container>
                <Link to="/">
                    <img src={logo} alt="costs" />
                </Link>
                <ul className={style.list}>
                    <li className={style.itens}><Link to="/">Home</Link></li>
                    <li className={style.itens}><Link to="/Projetos">Projetos</Link></li>
                    <li className={style.itens}><Link to="/Empresa">Empresa</Link></li>
                    <li className={style.itens}><Link to="/Contato">Contato</Link></li>
                </ul>
            </Container>
        </nav>
    )
}

export default NavBarra