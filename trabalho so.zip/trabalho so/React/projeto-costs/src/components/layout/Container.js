import style from './Container.module.css'

function Container(props){
    return(
        <div className={`${style.container} ${style[props.customClass]}`}>
            {props.children}
        </div>
    )
}

export default Container

//nesse container eu vou alterar classes que eu possa mudar
// a disposição dos meus itens do container