import { useLocation } from "react-router-dom"
import { useState, useEffect} from "react"

import Container from "../layout/Container"
import style from './Projetos.module.css'
import LinkButton from "../layout/LinkButton"
import ProjetoCard from "../projects/ProjetoCard"
import Messeger from "../layout/Messeger"
import Loading from "../layout/Loading"


function Projetos(){

    const[projetos, setProjetos] = useState([])
    const [removeLoader, setRemoveLoader] = useState(false)
    const [projetoMsg, setProjetoMsg] = useState('')


    const location = useLocation()
    let message = ''
    if(location.state){
        message = location.state.message
    }

    useEffect(()=>{
        setTimeout(()=>{
            fetch("http://localhost:5000/project", {
                method: 'GET',
                headers: {
                    'Content-Type': "application/json",
                    
                },
    
            }).then((resp)=> {if (!resp.ok) {
                throw new Error("Erro ao buscar projetos");
            }
            return resp.json();})
            .then((data) => {
                setProjetos(data)
                setRemoveLoader(true)
            })
            .catch((err)=> console.log(err))
        }, 3000)

    }, [])

    function removeProjeto(id){
        fetch(`http://localhost:5000/project/${id}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': "application/json"
            }
        }) .then((resp) => {
            if (!resp.ok) {
                throw new Error("Erro ao excluir projeto");
            }
            return resp.json();
        })
        .then((data)=>{
            setProjetos((prevProjetos) => prevProjetos.filter((projeto)=> projeto.id !== id))
            setProjetoMsg("Projeto removido com sucesso")
        })
        .catch((err) => console.log("Erro ao excluir:", err));
    }

    return (
        <div className={style.project_container}>
            <div className={style.tittle_container}>
                <h1>Meus projetos</h1>
                <LinkButton to={"/NovoProjeto"} text="Criar novo Projeto"/>
            </div>
            {message && <Messeger type="sucess" msg={message}/>}
            {projetoMsg && <Messeger type="sucess" msg={projetoMsg}/>}

            <Container customClass="start">
                {projetos.length > 0 && projetos.map((projeto) => 
                
                <ProjetoCard 
                key={projeto.id} 
                id={projeto.id} 
                name={projeto.name}
                budget={projeto.orcamento}
                category={projeto.categoria}
                handleRemove={removeProjeto}
                />
                )}
                {!removeLoader && <Loading/>}
                {removeLoader && projetos.length === 0 && (
                    <p>Não há projetos Cadastrado</p>
                )}

            </Container>
        
        </div>
    )
}
export default Projetos