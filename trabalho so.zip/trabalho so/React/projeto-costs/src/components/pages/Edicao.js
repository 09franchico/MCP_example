import style from './Edicao.module.css'
import { useParams } from 'react-router-dom'
import { useState, useEffect } from 'react'
import Loading from '../layout/Loading'
import Container from '../layout/Container'
function Edicao(){
    const {id} = useParams()
    

    const[projeto, setProjeto] = useState([])

    const [showProjetoForm, setShowProjetoForm] = useState(false)

    useEffect(()=>{

        setTimeout(()=>{
            fetch((`http://localhost:5000/project/${id}`), {
                method: 'GET',
                headers:{
                    'Content-Type': 'application/json',
                },
            }).then((resp) => resp.json())
            .then((data) => {
                setProjeto(data)
            })
            .catch((err)=>  console.log(err))
        }, 3000)
    }, [id])


    function toggleProjetoForm(){
        setShowProjetoForm(!showProjetoForm)
    }

    return(
        <>
            {projeto.name ?
            (<div className={style.edicao}>
                <Container customClass="column">
                    <div className={style.edicao_cont}>
                        <h1>Projeto: {projeto.name}</h1>
                        <button className={style.btn} onClick={toggleProjetoForm}>{!showProjetoForm ? 'Editar Projeto': 'Fechar'}</button>

                        {!showProjetoForm ? (
                            <div className={style.projeto_info} >
                                <p>
                                    <span>Categoria:</span> {projeto.categoria.name}
                                </p>
                                <p>
                                    <span>Total de Orcamento:</span> r${projeto.orcamento}
                                </p>
                                <p>
                                    <span>Total utilizado:</span> r${projeto.costs}
                                </p>
                            </div>
                            
                        ):(
                            <div className={style.projeto_info}>
                                <p>
                                    <span>form</span> 
                                </p>
                            </div>
                        ) }
                    </div>
                </Container>
            </div>)
            : (<Loading/>)
            }
        </>
        
    )
}

export default Edicao