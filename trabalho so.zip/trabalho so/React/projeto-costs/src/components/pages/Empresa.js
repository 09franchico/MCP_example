function Empresa(){
    return <h1>Empresa</h1>
}

export default Empresa