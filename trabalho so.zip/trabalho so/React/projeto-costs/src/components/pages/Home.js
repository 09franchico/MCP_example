import style from './Home.module.css'
import saving from '../../img/saving.svg'
import LinkButton from '../layout/LinkButton'
function Home(){
    return(
        <section className={style.home_container}>
            <h1>Bem-vindo ao <span>Costs</span></h1>
            <p>Comece a gerenciar seus projetos</p>
            <LinkButton to={"/NovoProjeto"} text="Criar novo Projeto"/>
            <img src={saving} alt="saving" />
        </section>
    )
}

export default Home