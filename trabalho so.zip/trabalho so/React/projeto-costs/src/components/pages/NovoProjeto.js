import { useNavigate } from 'react-router-dom'
import style from './NovoProjeto.module.css'
import ProjetoForm from '../projects/ProjetoForm'

function NovoProjeto(){
    const history = useNavigate()

    function CreatePost(project){

        // incializando notasciradas e service
        project.costs = 0
        project.services = []

        fetch("http://localhost:5000/project",{
            method: 'POST'  ,
            headers: {
                'Content-Type': "application/json",
            },
            body: JSON.stringify(project)
        }).then((resp)=>resp.json())
        .then((data)=>{
        
            //redirect
            history('/Projetos', { state: { message: 'Projeto criado com sucesso' } })

        })
        .catch((err)=> console.log(err))


    }

    return(
        <div className={style.np_container}>
            <h1>Criar Projetos</h1>
            <p>Crie seu projeto e adicione serviços</p>
            <ProjetoForm handleSubmit={CreatePost} btnText="Criar Projeto"/>
        </div>
    )
}

export default NovoProjeto