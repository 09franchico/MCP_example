import { BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import Contato from './components/pages/Contato';
import Home from './components/pages/Home';
import Empresa from './components/pages/Empresa';
import NovoProjeto from './components/pages/NovoProjeto';

import Container from './components/layout/Container';
import NavBarra from './components/layout/NavBarra';
import Footer from './components/layout/Footer';
import Projetos from './components/pages/Projetos';
import Edicao from './components/pages/Edicao';

function App() {
  return (
    <Router>
      <NavBarra/>
      <Container customClass="min-height">
        <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/Empresa' element={<Empresa/>}/>
          <Route path='/Contato' element={<Contato/>}/>
          <Route path='/NovoProjeto' element={<NovoProjeto/>}/>
          <Route path='/Projetos' element={<Projetos/>}/>
          <Route path='/Edicao/:id' element={<Edicao/>}/>
        </Routes>
      </Container>
      <Footer/>
    </Router>
  )
}

export default App;
