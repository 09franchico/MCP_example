import Botao from "./eventos/Botao";

function Eventos(){

    function meuEvento(){
        console.log("ativado!");
    }

    function SegundoEvento(){
        console.log("ativando o segundo evento")
    }

    return(
        <div>
            <p>clique para disparar um evento:</p>
            <Botao event={meuEvento} text=" botao"/>
            <Botao event={SegundoEvento} text=" botao 2"/>

        </div>
    )
}
 
export default Eventos