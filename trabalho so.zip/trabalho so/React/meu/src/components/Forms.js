import styles from './Forms.module.css'
import { useState } from 'react';
function Forms(){


    const [name, setName] = useState("");
    const [password, setPassword] = useState(""); 
    
    function cadastrarUser(e){
        e.preventDefault();
      
        console.log(`usuario ${name} foi cadastrado com a senha ${password}`)
    }

   


    return(
        <div className={styles.container}>
            <h1>Formulario</h1>
            <form onSubmit={cadastrarUser}>
                <div>
                    <label htmlFor="name">Nome:</label>
                    <input type="text" 
                    id="name" 
                    name="name" 
                    placeholder="digite seu nome"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    />
                    

                </div>
                <div>
                    <label htmlFor="password">Senha:</label>
                    <input type="password" 
                    id="password" 
                    name="password"
                    placeholder="insira a senha" 
                    value={password} 
                    onChange={(e) => setPassword(e.target.value)}/>
                </div>
                <div>
                    <input type="submit" value="Cadastrar" />
                </div>
            </form>
        </div>
    )

}

export default Forms 