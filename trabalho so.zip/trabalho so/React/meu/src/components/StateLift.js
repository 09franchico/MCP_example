function StateLift({setNome}){
    return(
        <div>
            <p>digite seu Nome:</p>
            <input type="text" name="nome" id="nome" placeholder="qual é o seu nome:" 
            onChange={(e) => setNome(e.target.value)}/>

        </div>
    )

}

export default StateLift