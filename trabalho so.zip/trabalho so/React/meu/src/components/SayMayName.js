function SayMayName(props){
    return(
        <div>
            <p>Fala aí {props.name}, suave?</p>
        </div>     
    )
}
export default SayMayName