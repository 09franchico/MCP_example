import Item from "./Item"

function List(){

    return(
        <>
            <h1>componente List</h1>
            <ul>
                <Item marca="LG" ano_lancamento={1997}/>
                <Item marca="Samsung" ano_lancamento={1987}/>
                <Item marca="Lenovo" ano_lancamento={2000}/>
                <Item/>
            </ul>
        </>
    )
}

export default List