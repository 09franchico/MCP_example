import { useState } from "react"

function Condicional(){

    const [email, setEmail] = useState("")
    const [userEmail, setUserEmail] = useState("")

    function enviarEmail(e){
        e.preventDefault()
        setUserEmail(email)
       // console.log(userEmail)
        
    }
    function  limparEmail(){
        setUserEmail("")
    }
    return(
        <div>
            <h2>cadastre seu email:</h2>
            <form action="">
                <label htmlFor="email">Email:</label>
                <input type="text" 
                name="emai" 
                id="email" 
                placeholder="digite seu email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}/>
            </form>
            <button onClick={enviarEmail}> Enviar email </button>
            {userEmail &&(
                <div>
                    <p>o emial do usuario é: {userEmail}</p>
                    <button onClick={limparEmail}> limpar email</button>
                </div>
            )}
        </div>
    )
}

export default Condicional