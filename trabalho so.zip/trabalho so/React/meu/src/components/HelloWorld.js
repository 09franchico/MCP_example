import Frase from './Frase'

function HelloWorld(){
    return(
        <div> <Frase/>
            <h1>meu primeiro componente</h1>
            
        </div>
    )
}

export default HelloWorld