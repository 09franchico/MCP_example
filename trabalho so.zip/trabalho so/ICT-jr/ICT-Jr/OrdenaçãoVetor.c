#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include "arquivos .h/cria_vet.h"
#include "arquivos .h/AlgoritmosOrdenacaoVetor.h"

#define TAM 10
#define ITERACOES 10  // Número de repetições

int vetD[TAM], vetBubble[TAM], vetInsertion[TAM], vetSelection[TAM], vetMerge[TAM], vetQuick[TAM], vetHeap[TAM];

typedef struct {
    double tempoTotal;
    int comparacoesTotal;
} Estatisticas;

// Função para imprimir o vetor
void imprimeVetor(const char* mensagem, int* vet) {
    printf("%s: [", mensagem);
    for (int i = 0; i < TAM; i++) {
        printf("%d", vet[i]);
        if (i < TAM - 1) printf(", ");
    }
    printf("]\n");
}

// Função auxiliar para executar a ordenação e acumular estatísticas
void executaOrdenacao(void (*sortFunction)(int*, int), const char* nome, int* vet, FILE* fp, Estatisticas* stats) {
    memcpy(vet, vetD, sizeof(vetD));  // Copia o vetor desordenado para garantir que é o mesmo em todas as execuções
    
    printf("\nAntes de %s:\n", nome);
    imprimeVetor("Vetor Desordenado", vet);

    __resetaComparacoes();

    clock_t inicio = clock();
    sortFunction(vet, TAM);
    clock_t fim = clock();

    double tempo = ((double)(fim - inicio) / CLOCKS_PER_SEC);
    int totalComparacoes = numComparacoes();

    // Acumulando valores para calcular a média depois
    stats->tempoTotal += tempo;
    stats->comparacoesTotal += totalComparacoes;
    imprimeVetor("Vetor ordenado", vet);
    // Escrevendo os dados da iteração no arquivo
    fprintf(fp, "%s, %.8lf, %d, %d\n", nome, tempo, TAM, totalComparacoes);
}

int main() {
    criavetDesordenado(vetD, TAM);

    FILE *fp = fopen("tabelas/NovosTestes.csv", "a+");
    if (!fp) {
        printf("Erro ao abrir arquivo\n");
        exit(1);
    }
    fseek(fp, 0, SEEK_END);

    Estatisticas bubbleStats = {0, 0};
    Estatisticas selectionStats = {0, 0};
    Estatisticas insertionStats = {0, 0};
    Estatisticas mergeStats = {0, 0};
    Estatisticas quickStats = {0, 0};
    Estatisticas heapStats = {0, 0};

    for (int i = 0; i < ITERACOES; i++) {
        fprintf(fp, "\n===== VETOR %d =====\n", i + 1);
        fprintf(fp, "Algoritmo, Tempo, Tam Vetor, Comparações \n");
        
        printf("\nVetor Original antes de qualquer ordenação:\n");
        imprimeVetor("Vetor Inicial", vetD);

        executaOrdenacao(bubbleSort, "Bubble Sort", vetBubble, fp, &bubbleStats);
        executaOrdenacao(selectionSort, "Selection Sort", vetSelection, fp, &selectionStats);
        executaOrdenacao(insertionSort, "Insertion Sort", vetInsertion, fp, &insertionStats);
        executaOrdenacao(mergeSort, "Merge Sort", vetMerge, fp, &mergeStats);
        executaOrdenacao(quickSort, "Quick Sort", vetQuick, fp, &quickStats);
        executaOrdenacao(heapSort, "Heap Sort", vetHeap, fp, &heapStats);

        fprintf(fp, "\n");

        // Gerando um novo vetor desordenado para a próxima iteração
        criavetDesordenado(vetD, TAM);
    }

    fprintf(fp, "\n--- MÉDIAS APÓS %d ITERAÇÕES ---\n", ITERACOES);
    fprintf(fp, "Bubble Sort, %.8lf, %d\n", bubbleStats.tempoTotal / ITERACOES, bubbleStats.comparacoesTotal / ITERACOES);
    fprintf(fp, "Selection Sort, %.8lf, %d\n", selectionStats.tempoTotal / ITERACOES, selectionStats.comparacoesTotal / ITERACOES);
    fprintf(fp, "Insertion Sort, %.8lf, %d\n", insertionStats.tempoTotal / ITERACOES, insertionStats.comparacoesTotal / ITERACOES);
    fprintf(fp, "Merge Sort, %.8lf, %d\n", mergeStats.tempoTotal / ITERACOES, mergeStats.comparacoesTotal / ITERACOES);
    fprintf(fp, "Quick Sort, %.8lf, %d\n", quickStats.tempoTotal / ITERACOES, quickStats.comparacoesTotal / ITERACOES);
    fprintf(fp, "Heap Sort, %.8lf, %d\n", heapStats.tempoTotal / ITERACOES, heapStats.comparacoesTotal / ITERACOES);
    fprintf(fp, "\n");

    fclose(fp);
    return 0;
}
