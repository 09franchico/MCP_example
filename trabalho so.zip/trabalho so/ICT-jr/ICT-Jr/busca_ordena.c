#include "arquivos .h/busca_ordena.h"
#include  <stdlib.h>

static int NUM_COMP = 0;

static void __resetaComparacoes(){
    NUM_COMP = 0;
}

int numComparacoes(){
    return NUM_COMP;
}


int busca_binaria(int vet[], int tam, int chave){
    __resetaComparacoes();
    int inicio = 0, fim = tam-1, meio;
    while (fim - inicio >= 0){
        NUM_COMP++;
        meio = (inicio+fim)/2;
        if (vet[meio] > chave) fim = meio-1;
        else if (vet[meio] < chave) inicio = meio+1;
        else return meio;
    }
    return -1;
}

int busca_sequencial (int vet[], int tam, int chave){
    int i = 0;
    __resetaComparacoes();
    for (; i < tam; i++){
        NUM_COMP++;
        if (vet[i] == chave) return i;
    }
    return -1;
}

void bubbleSort (int vet[], int tam){
    int tmp;
    for (int i = 0; i < tam; i++){
        for (int j = 0; j < tam; j++){
            if (vet[j] > vet[j+1]){
                tmp = vet[j];
                vet[j] = vet[j+1];
                vet[j+1] = tmp;
            }
        }
    }
}

void selectionSort (int vet[], int tam){
    int pos_menor, tmp;
    for (int i = 0; i < tam; i++){
        pos_menor = i;
        for (int j = 0; j < tam; j++){
            if (vet[j] < vet[pos_menor]) pos_menor = j;
        }
        tmp = vet[i];
        vet[i] = vet[pos_menor];
        vet[pos_menor] = tmp;
    }
}

void insertionSort (int vet[], int tam){
    int pivot, j;
    for (int i = 1; i < tam; i++){
        pivot = vet[i];
        j = i-1;
        while ((j >= 0) && (vet[j] > pivot)){
            vet[j+1] = vet[j];
            j--;
        }
        vet[j+1] = pivot;
    }
}

void quickSortR (int vet[], int inicio, int fim){
    int pivot, tmp;
    int i = inicio, j = fim;
    if (i <= j){
        pivot = vet[(inicio + fim)/2];
        while (i <= j){
            while (vet[i] < pivot) i++;
            while (vet[j] > pivot) j--;
            if (i <= j){
                tmp = vet[i];
                vet[i] = vet[j];
                vet[j] = tmp;
                i++; j--;
            }
        }
    quickSortR(vet, inicio, j);
    quickSortR(vet, i, fim);
    }
}

void quickSort (int vet[], int tam){
    quickSortR(vet, 0, tam-1);
}


void mergeSortR (int vet[], int aux[], int inicio, int fim){
    int meio;

    if (inicio < fim){
        meio = (inicio + fim)/2;

        mergeSortR(vet, aux, inicio, meio);
        mergeSortR(vet, aux, meio+1, fim);

        unsigned i = inicio, j = meio + 1, k = inicio ;

        while ((i <= meio) && (j <= fim)){
            if (vet[i] < vet[j]){
                aux[k] = vet[i];
                i++;
            }
            else{
                aux[k] = vet[j];
                j++;
            }
            k++;
        }

        while (i <= meio){
            aux[k] = vet[i];
            i++;
            k++;
        }

        while (j <= fim){
            aux[k] = vet[j];
            j++;
            k++;
        }

        for (k = inicio; k <= fim; k++) vet[k] = aux[k];
    }
}

void mergeSort (int vet[], int tam){
    int *aux = malloc(sizeof(int) * tam);

    mergeSortR(vet, aux, 0, tam -1);
    
    free(aux);
}


// // opcionais
// void countingSort (int vet[], int tam){

// }

// void heapSort (int vet[], int tam){
// já tenho código
// }

// void bucketSort (int vet[], int tam){

// }

// void radixSort (int vet[], int tam){

// }