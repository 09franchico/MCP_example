#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include "arquivos .h/arvore.h"

typedef struct tipoNo {
    struct tipoNo *dir;
    struct tipoNo *esq;
    int valor;
} tipoNo;

typedef struct tipoAb {
    tipoNo *raiz;
    int tam;
} tipoAb;

static int NUM_COMP_AB = 0;

static void __resetaComparacoes(){
    NUM_COMP_AB = 0;
}

int numComparacoesArvore(){
    return NUM_COMP_AB;
}

tipoAb* criaAb() {
    tipoAb *ab = malloc(sizeof(tipoAb));
    if (!ab) return NULL;
    ab->raiz = NULL;
    ab->tam = 0;
    return ab;
}

static tipoNo* __criaNo(int num){
    tipoNo* novo = malloc(sizeof(tipoNo));
    if (!novo) return NULL;
    novo->dir = NULL;
    novo->esq = NULL;
    novo->valor = num;
    return novo;
}

static tipoNo* __insereAb(tipoNo *raiz, tipoNo *elem){
    if (!raiz) return elem; 
    if (elem->valor < raiz->valor) 
        raiz->esq = __insereAb(raiz->esq, elem); 
    else 
        raiz->dir = __insereAb(raiz->dir, elem); 

    return raiz;
}


void insereAb(tipoAb *ab, int num){
    tipoNo *elem = __criaNo(num);
    ab->raiz=__insereAb(ab->raiz, elem);
    ab->tam++;
}

static void __mostraAb(tipoNo *raiz){
    if (!raiz) {
        return;
    }
    __mostraAb(raiz->esq);
    printf("%d ", raiz->valor);
    __mostraAb(raiz->dir);
} 

void mostraAb(tipoAb *ab){
    __mostraAb(ab->raiz);
    printf("\n");
}

static int __buscarNo(tipoNo *raiz, int num){
    if (!raiz) return -1;
    NUM_COMP_AB++;
    if (raiz->valor == num) return num;

    if (raiz->valor < num) return __buscarNo(raiz->dir,num);
    else return __buscarNo(raiz->esq,num);

}

int buscarNo(tipoAb *ab, int num){
    __resetaComparacoes();
    usleep(500);
    return __buscarNo(ab->raiz, num);
}

int arvoreTam(tipoAb *ab){
    return ab->tam;
}