#include "arquivos .h/AlgoritmosOrdenacaoVetor.h"
#include  <stdlib.h>

static int NUM_COMP = 0;

void __resetaComparacoes(){
    NUM_COMP = 0;
}

int numComparacoes(){
    return NUM_COMP;
}

static void trocar(int vet[], int i, int j){
    int aux = vet[i];
    vet[i] = vet[j];
    vet[j] = aux;
}

void bubbleSort (int vet[], int tam){
    for (int i = 0; i < tam; i++){
        for (int j = 0; j < tam-1; j++){
            NUM_COMP++;
            if (vet[j] > vet[j+1]) trocar(vet,j, j+1);
        }
    }
}

void selectionSort (int vet[], int tam){
    int pos_menor;
    for (int i = 0; i < tam; i++){
        pos_menor = i;
        for (int j = i +1; j < tam; j++){
            NUM_COMP++;
            if (vet[j] < vet[pos_menor]) pos_menor = j;
        }
        trocar(vet, i, pos_menor);
    }
}

void insertionSort (int vet[], int tam){
    int pivot, j;
    for (int i = 1; i < tam; i++){
        pivot = vet[i];
        j = i-1;
        while((j >= 0) && (++NUM_COMP && vet[j] > pivot)){
            vet[j+1] = vet[j];
            j--;
        }
        vet[j+1] = pivot;
    }
}

static void quickSortR (int vet[], int inicio, int fim){
    int pivot;
    int i = inicio, j = fim;
    if (i <= j){
        pivot = vet[(inicio + fim)/2];
        while (i <= j){
            while (vet[i] < pivot){
                NUM_COMP++; // Incrementa comparações
                i++;
            }
            NUM_COMP++; //comparação que quebra o loop
            while (vet[j] > pivot){
                NUM_COMP++; // Incrementa comparações
                j--;
            }
            NUM_COMP++; //comparação que quebra o loop
            if (i <= j){
                trocar(vet,i,j);
                i++; j--;
            }
        }
        if (inicio < j) quickSortR(vet, inicio, j);
        if (i < fim) quickSortR(vet, i, fim);
    }
}

void quickSort (int vet[], int tam){
    quickSortR(vet, 0, tam-1);
}


static void mergeSortR (int vet[], int aux[], int inicio, int fim){
    int meio;

    if (inicio < fim){
        meio = (inicio + fim)/2;

        mergeSortR(vet, aux, inicio, meio);
        mergeSortR(vet, aux, meio+1, fim);

        unsigned i = inicio, j = meio + 1, k = inicio ;

        while ((i <= meio) && (j <= fim)){
            NUM_COMP++; // Incrementa comparações
            if (vet[i] < vet[j]){
                aux[k] = vet[i];
                i++;
            }
            else{
                aux[k] = vet[j];
                j++;
            }
            k++;
        }

        while (i <= meio){
            aux[k] = vet[i];
            i++;
            k++;
        }

        while (j <= fim){
            aux[k] = vet[j];
            j++;
            k++;
        }

        for (k = inicio; k <= fim; k++) vet[k] = aux[k];
    }
}

void mergeSort (int vet[], int tam){
    int *aux = malloc(sizeof(int) * tam);

    mergeSortR(vet, aux, 0, tam -1);
    
    free(aux);
}


void heapSort (int vet[], int tam){
    int k = (tam-1)/2;
    // construção do heap
    while (k >= 0){
        int i = k, imaior = i;
        do{
            i = imaior;
            if(2*i + 1 < tam){
                NUM_COMP++;
                if(vet[i] < vet[2*i+1]) imaior = 2 * i + 1;
            }

            if(2*i + 2 < tam) {
                NUM_COMP++;
                if(vet[imaior] < vet[2 *i +2]) imaior = 2 * i + 2; }

            if (i != imaior) trocar(vet,i,imaior);

        }while (i != imaior);
        k--;
    }
    int ult = tam-1;
    while(ult >= 1){
        trocar(vet,0,ult);
        ult--;
        // desce no heap
        int i = 0, imaior = i;
        do{
            i = imaior;
            if ((2*i + 1 <= ult) && (++NUM_COMP && vet[i] < vet[2*i+1])) imaior = 2 * i + 1;

            if ((2*i + 2 <= ult) && (++NUM_COMP && vet[imaior] < vet[2 *i +2])) imaior = 2 * i + 2; 

            if (i != imaior) trocar(vet,i,imaior); 

        }while(i != imaior);
    } 
}



// void countingSort (int vet[], int tam){

// }

// void bucketSort (int vet[], int tam){

// }

// void radixSort (int vet[], int tam){

// }