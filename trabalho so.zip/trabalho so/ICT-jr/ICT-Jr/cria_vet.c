#include <stdlib.h>
#include <stdio.h>
#include "arquivos .h/cria_vet.h"


void mostravet(int vet[], int inicio, int fim){
    printf("[");
    for (int i = inicio; i < fim-1; i++) printf("%d, ",vet[i]);
    printf("%d]\n",vet[fim-1]);
}

void criavetOrdenado(int vet[], int tam, int incremento){
    int valor = 0;
    for (int i = 0; i < tam; i++) {
        vet[i] = valor;
        valor += incremento;
    }
}

void criavetDesordenado(int vet[], int tam){
    for (int i = 0; i < tam; i++) vet[i] = rand() % 2000000;
}
