typedef struct tipoNo tipoNo;

typedef struct tipoAb tipoAb;

tipoAb* criaAb();

void insereAb(tipoAb *ab, int num);

void mostraAb(tipoAb *ab);

int buscarNo(tipoAb *ab, int num);
int numComparacoesArvore();
int arvoreTam(tipoAb *ab);