#ifndef BUSCAS_H
#define BUSCAS_H

int numComparacoes();
int busca_binaria(int vet[], int tam, int chave);
int busca_sequencial (int vet[], int tam, int chave);

#endif