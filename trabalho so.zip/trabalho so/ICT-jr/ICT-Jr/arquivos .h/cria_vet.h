#ifndef CRIA_H
#define CRIA_H
void criavetOrdenado(int vet[], int tam, int incremento);

void criavetDesordenado(int vet[], int tam);

void mostravet(int vet[], int inicio, int fim);
#endif