#ifndef ORDENACAO_H
#define ORDENACAO_H
void __resetaComparacoes();
int numComparacoes();
void bubbleSort (int vet[], int tam);
void selectionSort (int vet[], int tam);
void insertionSort (int vet[], int tam);

void quickSort (int vet[], int tam);
void mergeSort (int vet[], int tam);
void heapSort (int vet[], int tam);

#endif