#include <stdlib.h>
#include <stdio.h>
#include "arquivos .h/lista.h"

static int NUM_COMP_LISTA = 0;

static void __resetaComparacoes(){
    NUM_COMP_LISTA = 0;
}

int numComparacoesLista(){
    return NUM_COMP_LISTA;
}

typedef struct tipoNo{
    struct tipoNo *prox;
    int chave;
} tipoNo;

typedef struct tipoLista{
    tipoNo *prim;
    unsigned tam;
    func_comp cmp;
} tipoLista;


int listaTam(tipoLista *l){
    return l->tam;
}

static int __func_comp(int n1, int n2){
    return (n1 - n2);
}

tipoLista *criaLista(){
    tipoLista *l = malloc(sizeof(tipoLista));
    l->prim = NULL;
    l->tam = 0;
    l->cmp = __func_comp;
    return l;
}

static tipoNo *__criaElem(int chave){
    tipoNo *e = malloc(sizeof(tipoNo));
    e->prox = NULL;
    e->chave = chave;
    return e;
}

void insereFim(tipoLista *l, int chave){
    tipoNo *elem = __criaElem(chave);
    tipoNo *aux = l->prim;
    if (aux){
        while(aux->prox) aux = aux->prox;
        aux->prox = elem;
    }
    else{
        l->prim = elem;
    }
    l->tam++;
}

void insereInicio(tipoLista *l, int chave){
    tipoNo *elem = __criaElem(chave);
    if (l->prim){
        elem->prox = l->prim;
        l->prim = elem;
    }
    else l->prim = elem;

    l->tam++;
}

int buscaElem(tipoLista *l, int chave){
    tipoNo *aux = l->prim;
    __resetaComparacoes();
    int i = 0; 
    while ((aux) && (aux->chave != chave)){
        NUM_COMP_LISTA++;
        i++;
        aux = aux->prox;
    }
    return aux ? i : -1;
}

void criaInsereElem(tipoLista *lista, int num_elems){
    for (int i = num_elems; i > 0; i--) insereInicio(lista, i);
}

void imprimeLista(tipoLista *l){
    tipoNo *aux = l->prim;
    while (aux){
        printf("Chave: %d\n",aux->chave);
        aux = aux->prox;
    }
}