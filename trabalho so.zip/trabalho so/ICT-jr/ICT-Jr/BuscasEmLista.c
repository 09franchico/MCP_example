#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "arquivos .h/lista.h"
#include "arquivos .h/cria_vet.h"
#include "arquivos .h/AlgoritmosBuscaVetor.h"

#define TAM_VET_BUSC 30


void numeros_buscados (int vetGuarda[], int vetOrigin[], int tamVetOrigin){ 
    int i = 0;
    for (; i < TAM_VET_BUSC-10; i++) vetGuarda[i] = vetOrigin[rand() % tamVetOrigin];
    for (; i < TAM_VET_BUSC; i++) vetGuarda[i] = rand() % 20000;
}

int main(int argc, char* argv[]){
    if (argc < 2) return 0;
    int TAM_VETOR = atoi(argv[1]);

    srand(time(NULL));
    FILE *fp = fopen("tabelas/NovaBuscasEmLista.csv", "r+");
    if (!fp){
        printf("erro\n");
        exit(1);
    }
    fseek(fp, 0, SEEK_END);

    srand(time(NULL));
    int vetBuscado[TAM_VET_BUSC];
    int vetorDesordenado[TAM_VETOR];
    criavetDesordenado(vetorDesordenado, TAM_VETOR);
    numeros_buscados(vetBuscado,vetorDesordenado, TAM_VETOR);

    tipoLista *lista = criaLista();
    for (int i = TAM_VETOR-1; i >= 0; i--){
        insereInicio(lista,vetorDesordenado[i]);
    }

    clock_t inicio, fim;
    double tempo, tempos[TAM_VET_BUSC];
    int saida;
    double soma = 0;

    double desvio = 0;
    printf("\nBUSCA EM LISTA\n");
    for (int i = 0; i < TAM_VET_BUSC; i++){
        inicio = clock(); saida = buscaElem(lista, vetBuscado[i]); fim = clock();
        tempo = ((double)(fim - inicio) / CLOCKS_PER_SEC);
        soma += tempo;
        tempos[i] = tempo;
        printf("%2.d - TEMPO %.8lfs | N EXEC: %d\n", (i+1), tempo, numComparacoesLista());
        fprintf(fp,"Lista,%d,%.8lf,%d,%d\n", saida, tempo, numComparacoesLista(), listaTam(lista));
    }

    double media = soma/TAM_VET_BUSC;
    printf("\nMedia do tempo: %.12lf |", media);

    for (int i = 0; i < TAM_VET_BUSC; i++) desvio += (tempos[i] - media)* (tempos[i] - media);
    desvio = sqrt(desvio/TAM_VET_BUSC);
    printf(" Desvio padrão: %.8lf\n\n", desvio);

    free(lista);
    
    soma = 0;
    desvio = 0;
    printf("\nBUSCA EM VETOR\n");
    for (int i = 0; i < TAM_VET_BUSC; i++){
        inicio = clock(); saida = busca_sequencial(vetorDesordenado, TAM_VETOR, vetBuscado[i]) ; fim = clock();
        tempo = ((double)(fim - inicio) / CLOCKS_PER_SEC);
        soma += tempo;
        tempos[i] = tempo;
        printf("%2.d - TEMPO %.8lfs | N EXEC: %d\n", (i+1), tempo, numComparacoes());
        fprintf(fp,"Vetor,%d,%.8lf,%d,%d\n", saida, tempo, numComparacoes(), TAM_VETOR);
    }
    media = soma/TAM_VET_BUSC;
    printf("\nMedia do tempo: %.12lf |", media);

    for (int i = 0; i < TAM_VET_BUSC; i++) desvio += (tempos[i] - media)* (tempos[i] - media);
    desvio = sqrt(desvio/TAM_VET_BUSC);
    printf(" Desvio padrão: %.8lf\n\n", desvio);
}