#include "arquivos .h/AlgoritmosBuscaVetor.h"
#include  <stdlib.h>
#include <unistd.h>


static int NUM_COMP = 0;

static void __resetaComparacoes(){
    NUM_COMP = 0;
}

int numComparacoes(){
    return NUM_COMP;
}


int busca_binaria(int vet[], int tam, int chave){
    __resetaComparacoes();
    sleep(0.5);
    int inicio = 0, fim = tam-1, meio;
    while (fim - inicio >= 0){
        NUM_COMP++;
        meio = (inicio+fim)/2;
        if (vet[meio] > chave) fim = meio-1;
        else if (vet[meio] < chave) inicio = meio+1;
        else return meio;
    }
    return -1;
}

int busca_sequencial (int vet[], int tam, int chave){
    int i = 0;
    __resetaComparacoes();
    for (; i < tam; i++){
        NUM_COMP++;
        if (vet[i] == chave) return i;
    }
    return -1;
}