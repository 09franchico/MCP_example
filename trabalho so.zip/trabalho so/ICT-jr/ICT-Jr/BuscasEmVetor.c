#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "arquivos .h/AlgoritmosBuscaVetor.h"
#include "arquivos .h/cria_vet.h"

#define TAM_VET_BUSC 30
int tam;

void numeros_buscados (int vetGuarda[], int vetOrigin[], int tamVetOrigin){ 
    int i = 0;
    for (; i < TAM_VET_BUSC-10; i++) vetGuarda[i] = vetOrigin[rand() % tamVetOrigin];
    for (; i < TAM_VET_BUSC; i++) vetGuarda[i] = rand() % 2000000;
}

int main(int argc, char* argv[]){
    if (argc < 2) return 0;

    int tam = atoi(argv[1]);
    printf("%d\n", tam);
    srand(time(NULL));

    FILE *fp = fopen("tabelas/NovaBuscaEmVetor.csv", "r+");
    if (!fp){
        printf("erro\n");
        exit(1);
    }
    fseek(fp, 0, SEEK_END);
    
    int vetBusca[TAM_VET_BUSC], vetO[tam];
    
    criavetOrdenado(vetO, tam, 173);

    numeros_buscados(vetBusca, vetO, tam);

    clock_t inicio, fim;
    double tempo, tempos[TAM_VET_BUSC];
    int saida;
    double soma = 0;

    double desvio;
    printf("\nBUSCA SEQUENCIAL\n");
    for (int i = 0; i < TAM_VET_BUSC; i++){
        inicio = clock(); saida = busca_sequencial(vetO, tam, vetBusca[i]); fim = clock();
        tempo = ((double)(fim - inicio) / (CLOCKS_PER_SEC/1000));
        soma += tempo;
        tempos[i] = tempo;
        fprintf(fp,"Busca Sequencial,%d,%.8lf,%d,%d\n", saida ,tempo, numComparacoes(), tam);
        printf("%2.d - POS NO VET: %d | TEMPO %.8lfs | N EXEC/COMP: %d\n", (i+1), saida ,tempo, numComparacoes());
    }

    double media = soma/TAM_VET_BUSC;
    printf("\nMedia do tempo: %.12lf |", media);

    for (int i = 0; i < TAM_VET_BUSC; i++) desvio += (tempos[i] - media)* (tempos[i] - media);
    desvio = sqrt(desvio/TAM_VET_BUSC);
    printf(" Desvio padrão: %.8lf\n\n", desvio);

    soma = 0, media = 0, desvio = 0;
    printf("BUSCA BINÁRIA\n");
    for (int i = 0; i < TAM_VET_BUSC; i++){
        inicio = clock(); saida = busca_binaria(vetO, tam, vetBusca[i]); fim = clock();
        tempo = ((double) (fim - inicio)) / (CLOCKS_PER_SEC/1000);
        soma += tempo;
        tempos[i] = tempo;
        fprintf(fp,"Busca Binária,%d,%.8lf,%d,%d\n", saida ,tempo, numComparacoes(), tam);
        printf("%2.d - POS NO VET: %d | TEMPO %.8lfs | N EXEC/COMP: %d\n", (i+1),saida, tempo, numComparacoes());
    }

    media = soma/TAM_VET_BUSC;
    printf("\nMedia do tempo: %.12lf |", media);

    for (int i = 0; i < TAM_VET_BUSC; i++) desvio += (tempos[i] - media)* (tempos[i] - media);
    desvio = sqrt(desvio/TAM_VET_BUSC);
    printf(" Desvio padrão: %.8lf\n\n", desvio);
}