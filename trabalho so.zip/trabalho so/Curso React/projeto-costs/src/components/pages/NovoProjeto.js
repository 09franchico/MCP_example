import style from './NovoProjeto.module.css'
import ProjetoForm from '../projects/ProjetoForm'

function NovoProjeto(){
    
    return(
        <div className={style.np_container}>
            <h1>Criar Projetos</h1>
            <p>Crie seu projeto e adicione serviços</p>
            <ProjetoForm btnText="Criar Projeto"/>
        </div>
    )
}

export default NovoProjeto